package com.example.cosmoinfo.data.model.paper

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "papers")
data class PaperForDb(
    @PrimaryKey
    val id: Int,
    val category: String,
    val title: String,
    val content: String,
    val excerpt: String,
    var fullImageUrl: String,
    val thumbnailImageUrl: String,
    val mediumImageUrl: String
) {
    companion object {
        fun convertToDb(paper: Paper): PaperForDb {
            return PaperForDb(
                id = paper.id,
                category = "dsada",
                title = paper.title,
                content = paper.content,
                excerpt = paper.excerpt,
                fullImageUrl = paper.picture.fullPicture.fullPictureUrl,
                thumbnailImageUrl = paper.picture.thumbnailPicture.thumbnailPictureUrl,
                mediumImageUrl = paper.picture.mediumPicture.mediumPictureUrl
            )
        }

        fun convertFromDb(paperForDb: PaperForDb): Paper {
            return Paper(
                id = paperForDb.id,
                title = paperForDb.title,
                content = paperForDb.content,
                excerpt = paperForDb.excerpt,
                picture = Picture(
                    fullPicture = FullPicture(
                        paperForDb.fullImageUrl
                    ),
                    thumbnailPicture = ThumbnailPicture(
                        paperForDb.thumbnailImageUrl
                    ),
                    mediumPicture = MediumPicture(
                        paperForDb.mediumImageUrl
                    )
                )
            )
        }
    }
}