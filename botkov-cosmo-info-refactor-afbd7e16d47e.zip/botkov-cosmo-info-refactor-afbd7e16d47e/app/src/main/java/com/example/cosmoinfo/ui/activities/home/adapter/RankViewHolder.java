package com.example.cosmoinfo.ui.activities.home.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cosmoinfo.R;

public class RankViewHolder extends RecyclerView.ViewHolder {

    ImageView image;
    TextView title;
    TextView subTitle;
    LinearLayout start;

    public RankViewHolder(@NonNull View itemView) {
        super(itemView);

        image = itemView.findViewById(R.id.image_item_preview_category);
        title = itemView.findViewById(R.id.item_title_category);
        subTitle = itemView.findViewById(R.id.item_subtitle_category);
        start = itemView.findViewById(R.id.read_blog);

    }
}
