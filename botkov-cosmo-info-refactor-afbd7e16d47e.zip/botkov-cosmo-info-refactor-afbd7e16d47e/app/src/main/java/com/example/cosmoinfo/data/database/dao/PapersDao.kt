package com.example.cosmoinfo.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.cosmoinfo.data.model.paper.PaperForDb

@Dao
interface PapersDao {

    @Query("SELECT * FROM papers")
    suspend fun getAllArticles(): List<PaperForDb>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addAll(users: List<PaperForDb>)

    @Query("SELECT * FROM papers where category =:categoryName")
    suspend fun getArticlesSomeCategory(categoryName: String): List<PaperForDb>

    @Query("SELECT * FROM papers where id =:id")
    suspend fun getSomeArticle(id: Int): PaperForDb

    @Query("DELETE FROM papers")
    suspend fun deleteALlArticles()
}