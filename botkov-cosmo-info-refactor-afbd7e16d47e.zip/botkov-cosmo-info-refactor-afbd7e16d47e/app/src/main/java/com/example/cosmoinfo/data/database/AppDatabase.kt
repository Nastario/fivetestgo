package com.example.cosmoinfo.data.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.cosmoinfo.data.database.dao.BlogDao
import com.example.cosmoinfo.data.database.dao.PapersDao
import com.example.cosmoinfo.data.model.blog.BlogTable
import com.example.cosmoinfo.data.model.paper.Paper
import com.example.cosmoinfo.data.model.paper.PaperForDb

@Database(entities = [PaperForDb::class, BlogTable::class], version = 1, exportSchema = false)
abstract class AppDatabase: RoomDatabase() {
//    abstract val papersDao: PapersDao
    abstract val blogsDao: BlogDao
}