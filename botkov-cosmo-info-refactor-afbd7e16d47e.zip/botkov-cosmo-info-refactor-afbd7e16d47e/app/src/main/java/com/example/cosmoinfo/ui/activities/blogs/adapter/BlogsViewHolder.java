package com.example.cosmoinfo.ui.activities.blogs.adapter;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cosmoinfo.R;

public class BlogsViewHolder extends RecyclerView.ViewHolder {

    ImageView image;
    TextView title;
    TextView subTitle;

    public BlogsViewHolder(@NonNull View itemView) {
        super(itemView);

        image = itemView.findViewById(R.id.item_image_preview_article);
        title = itemView.findViewById(R.id.item_title_article);
//        subTitle = itemView.findViewById(R.id.item_subtitle_article);

    }
}
