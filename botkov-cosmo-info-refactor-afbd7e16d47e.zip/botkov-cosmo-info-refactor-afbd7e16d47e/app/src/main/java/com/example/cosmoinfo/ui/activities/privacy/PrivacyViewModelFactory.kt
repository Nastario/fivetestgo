package com.example.cosmoinfo.ui.activities.privacy

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.cosmoinfo.data.repository.Repository

class PrivacyViewModelFactory(private val repository: Repository,
) : ViewModelProvider.NewInstanceFactory() {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PrivacyViewModel::class.java)) {
            return PrivacyViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown View Model class")
    }
}