package com.example.cosmoinfo.ui.activities.splash

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cosmoinfo.data.repository.Repository
import com.example.cosmoinfo.data.services.LoadingState
import com.example.cosmoinfo.data.services.UrlLoadingState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SplashViewModel(private val repository: Repository) : ViewModel() {

    private val _liveDataUrlLoadingState = MutableLiveData<UrlLoadingState>()
    val livaDataUrlLoadingState: LiveData<UrlLoadingState> = _liveDataUrlLoadingState

    private val _liveDataBlogsLoadingState = MutableLiveData<LoadingState>()
    val liveDataBlogsLoadingState: LiveData<LoadingState> = _liveDataBlogsLoadingState

    init {
        subscribeLoadingState()
        subscribeBlogsLoadingState()
    }

    private fun subscribeBlogsLoadingState() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.sharedFlowBlogsLoadingState.collect {
                _liveDataBlogsLoadingState.postValue(it)
            }
        }
    }

    private fun subscribeLoadingState() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.sharedFlowInternetConnectionState.collect {
                _liveDataUrlLoadingState.postValue(it)
            }
        }
    }

    fun getBlogs(url: String){
        viewModelScope.launch(Dispatchers.IO) {
            repository.getBlogs(url)
        }
    }

    fun checkUrl() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.checkUrl()
        }
    }
}