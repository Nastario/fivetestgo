package com.example.cosmoinfo.ui.activities.privacy

import androidx.lifecycle.ViewModel
import com.example.cosmoinfo.data.repository.Repository

class PrivacyViewModel(private val repository: Repository): ViewModel() {
}