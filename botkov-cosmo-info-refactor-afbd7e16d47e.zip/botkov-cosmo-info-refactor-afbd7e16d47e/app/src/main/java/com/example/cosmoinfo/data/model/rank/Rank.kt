package com.example.cosmoinfo.data.model.rank

import com.example.cosmoinfo.R

data class Rank(
    val image: Int,
    val title: String,
    val subtitle: String
) {
    companion object {
        val ranks = listOf(
            Rank(
                R.drawable.category_space_objects,
                "Space Objects",
                "Asteroids, comets, meteoroids etc."
            ),

            Rank(
                R.drawable.category_planets,
                "Planets",
                "In Solar System"
            ),
            Rank(
                R.drawable.category_moons,
                "Moons",
                "In Solar System"
            ),

            Rank(
                R.drawable.category_asteroids,
                "Asteroids, Comets & Meteors",
                ""
            )
        )
    }
}