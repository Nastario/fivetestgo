package com.example.cosmoinfo.data.services.constants;

public class Const {
}
