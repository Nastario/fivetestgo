package com.example.cosmoinfo.ui.activities.splash

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import com.example.cosmoinfo.R
import com.example.cosmoinfo.data.di.Di
import com.example.cosmoinfo.data.services.LoadingState
import com.example.cosmoinfo.data.services.UrlLoadingState
import com.example.cosmoinfo.databinding.ActivitySplashBinding
import com.example.cosmoinfo.ui.activities.home.HomeActivity
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.*

class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding
    private lateinit var splashViewModel: SplashViewModel
    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.IO + job)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val factory = SplashViewModelFactory(Di.repository)
        splashViewModel = ViewModelProvider(this, factory)[SplashViewModel::class.java]

        subscribeUrlLoadingState()
        splashViewModel.checkUrl()
    }

    private fun subscribeUrlLoadingState() {
        if (!splashViewModel.livaDataUrlLoadingState.hasActiveObservers())
        splashViewModel.livaDataUrlLoadingState.observe(this) {
            Log.d("test", it.status.toString())
            when (it.status) {
                UrlLoadingState.Status.LOADING -> {
                    binding.progressBar.isVisible = true
                }
                UrlLoadingState.Status.SUCCESS -> {
                    subscribeBlogsLoadingState()
                    splashViewModel.getBlogs(it.msg.toString())

                }
                UrlLoadingState.Status.ERROR -> {
                    binding.progressBar.isVisible = false
                    showSnackBar()
                }
            }
        }
    }

    private fun subscribeBlogsLoadingState(){
        if (!splashViewModel.liveDataBlogsLoadingState.hasActiveObservers())
            splashViewModel.liveDataBlogsLoadingState.observe(this) {
                Log.d("test", it.status.toString())
                when (it.status) {
                    LoadingState.Status.LOADING -> {

                    }
                    LoadingState.Status.SUCCESS -> {
                        startHomeActivity()
                    }
                    LoadingState.Status.ERROR -> {
                        binding.progressBar.isVisible = false
                        showSnackBar()
                    }
                }
            }

    }

    private fun startHomeActivity() {
        scope.launch {
            delay(2000)
            val i = Intent(this@SplashActivity, HomeActivity::class.java)
            startActivity(i)
            coroutineContext.cancelChildren()
            finish()
        }
    }

    @SuppressLint("NewApi")
    private fun showSnackBar() {
        Snackbar.make(
            binding.root,
            this.getString(R.string.page_not_found),
            Snackbar.LENGTH_INDEFINITE
        )
            .setTextColor(this.getColor(R.color.white))
            .setBackgroundTint(this.getColor(R.color.pink))
            .setAction("Retry!") {
                splashViewModel.checkUrl()
            }
            .setActionTextColor(this.getColor(R.color.white))
            .show()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        scope.cancel()
    }
}