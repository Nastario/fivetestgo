package com.example.cosmoinfo.data.services.base_activity;

import androidx.appcompat.app.AppCompatActivity;

abstract public class BaseActivity extends AppCompatActivity {

    public abstract void init();

    public abstract void setClicks();

    public abstract void showToast(String massage);

    public abstract void showSnack(String massage);


}
