package com.example.cosmoinfo.data.services.network

import com.example.cosmoinfo.data.model.blog.Blog
import retrofit2.http.GET
import retrofit2.http.Url

interface ApiService {

    @GET
    suspend fun getBlogs(@Url url: String): List<Blog>
}