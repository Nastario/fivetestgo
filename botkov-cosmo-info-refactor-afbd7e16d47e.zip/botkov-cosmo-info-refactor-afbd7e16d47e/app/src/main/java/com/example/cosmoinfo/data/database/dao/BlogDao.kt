package com.example.cosmoinfo.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.cosmoinfo.data.model.blog.BlogTable
import kotlinx.coroutines.flow.Flow

@Dao
interface BlogDao {

    @Query("SELECT * FROM blogs")
    fun getBlogs(): List<BlogTable>

    @Query("SELECT * FROM blogs")
    fun getFlowBlogs(): Flow<List<BlogTable>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun addBlogs(blogs: List<BlogTable>)

    @Query("SELECT * FROM blogs where id =:id")
    fun getSomeBlog(id: Int): BlogTable

    @Query("DELETE FROM blogs")
    fun deleteBlogs()
}