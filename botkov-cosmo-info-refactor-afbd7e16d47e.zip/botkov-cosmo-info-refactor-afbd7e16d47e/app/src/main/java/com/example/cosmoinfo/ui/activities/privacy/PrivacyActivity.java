package com.example.cosmoinfo.ui.activities.privacy;

import android.os.Bundle;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.cosmoinfo.data.di.Di;
import com.example.cosmoinfo.data.services.base_activity.BaseActivity;
import com.example.cosmoinfo.databinding.ActivityPrivacyBinding;
import com.example.cosmoinfo.ui.activities.home.HomeViewModel;
import com.example.cosmoinfo.ui.activities.home.HomeViewModelFactory;
import com.google.android.material.snackbar.Snackbar;

public class PrivacyActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener {

    private ActivityPrivacyBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityPrivacyBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        PrivacyViewModelFactory factory = new PrivacyViewModelFactory(Di.INSTANCE.getRepository());
        PrivacyViewModel homeViewModel = new ViewModelProvider(this, (ViewModelProvider.Factory) factory).get(PrivacyViewModel.class);

        init();
        setClicks();
    }

    @Override
    public void init() {
        binding.privacyContent.setOnRefreshListener(this);
    }

    @Override
    public void setClicks() {
        binding.imageButtonBackPrivacy.setOnClickListener(view -> finish());
    }

    @Override
    public void showToast(String massage) {
        Toast.makeText(this, massage, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showSnack(String massage) {
        Snackbar snackbar = Snackbar.make(binding.getRoot(), massage, Snackbar.LENGTH_LONG);
        snackbar.show();
    }

    @Override
    public void onRefresh() {
    }

}