package com.example.cosmoinfo.data.model.blog

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlin.random.Random

@Entity(tableName = "blogs")
data class BlogTable(
    @PrimaryKey
    val id: Int,
    val title: String,
    val content: String,
    val img: String

) {
    companion object {
        fun blogsToDatabaseBlogs(blogs: List<Blog>): List<BlogTable> {
            return blogs.map {
                BlogTable(
                    id = Random.nextInt(),
                    title = it.title.rendered,
                    content = it.content.rendered,
                    img = it.img.isobar.replace(" ","")
                )
            }
        }
    }
}

data class Blog(
    val title: Rendered,
    val content: Rendered,
    val img: Isobar

)

data class Rendered(
    val rendered: String
)

data class Isobar(
    val isobar: String
)