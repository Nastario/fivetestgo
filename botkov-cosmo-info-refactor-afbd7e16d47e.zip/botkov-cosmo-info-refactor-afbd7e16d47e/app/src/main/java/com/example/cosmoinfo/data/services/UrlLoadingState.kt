package com.example.cosmoinfo.data.services

data class UrlLoadingState constructor(val status: Status, val msg: String? = null) {

    companion object {
        val LOADING = UrlLoadingState(Status.LOADING)
        fun success(url: String) = UrlLoadingState(Status.SUCCESS, url)
        fun error(msg: String) = UrlLoadingState(Status.ERROR, msg)
    }


    enum class Status {
        LOADING,
        SUCCESS,
        ERROR
    }
}