package com.example.cosmoinfo.ui.app;

import android.app.Application;

import com.example.cosmoinfo.data.di.Di;
import com.google.firebase.FirebaseApp;

public class CosmoApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Di.INSTANCE.init(this);
    }
}
