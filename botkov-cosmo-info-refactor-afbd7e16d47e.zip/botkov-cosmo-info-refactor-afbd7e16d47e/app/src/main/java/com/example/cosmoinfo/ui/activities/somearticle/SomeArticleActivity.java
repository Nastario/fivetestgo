package com.example.cosmoinfo.ui.activities.somearticle;

import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.widget.TextView;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.example.cosmoinfo.data.di.Di;
import com.example.cosmoinfo.data.services.base_activity.BaseActivity;
import com.example.cosmoinfo.databinding.ActivitySomeArticleBinding;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SomeArticleActivity extends BaseActivity {

    private static final String ARTICLE_ID = "article_id";

    private ActivitySomeArticleBinding binding;
    private String regexDigit = "(\\d+)";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySomeArticleBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        int id = getIntent().getExtras().getInt(ARTICLE_ID, -1);
        SomeArticleViewModelFactory factory = new SomeArticleViewModelFactory(Di.INSTANCE.getRepository(), id);
        SomeArticleViewModel someArticleViewModel = new ViewModelProvider(this, (ViewModelProvider.Factory) factory).get(SomeArticleViewModel.class);

        someArticleViewModel.getLiveDataSomeArticle().observe(this, somePaper -> {
            binding.title.setText(somePaper.getTitle());
            binding.contentSomeArticle.setText(highlightDigits(somePaper.getContent()), TextView.BufferType.SPANNABLE);
            Glide.with(this).load(somePaper.getImg()).into(binding.imageSomeArticle);
        });
        setClicks();
        someArticleViewModel.emitSomeArticle();
    }

    @Override
    public void init() {
    }

    @Override
    public void setClicks() {
        binding.imageButtonBack.setOnClickListener(view -> finish());
    }

    @Override
    public void showToast(String massage) {
        Toast.makeText(this, massage, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showSnack(String massage) {
        Snackbar snackbar = Snackbar.make(binding.getRoot(), massage, Snackbar.LENGTH_LONG);
        snackbar.show();
    }

    private Spanned highlightDigits(String original) {
        String clearText = original;
        ArrayList<String> originalDigits = new ArrayList<>();
        ArrayList<String> coloredDigits = new ArrayList<>();

        Pattern p = Pattern.compile(regexDigit);
        Matcher m = p.matcher(clearText);
        while (m.find()) {
            originalDigits.add(m.group());
        }
        for (int i = 0; i < originalDigits.size(); i++) {
            String digit = originalDigits.get(i);
            String coloredDigit = searchHighlightedKeyword(digit);
            coloredDigits.add(coloredDigit);
        }
        for (int i = 0; i < coloredDigits.size(); i++) {
            String whatReplace = originalDigits.get(i).toLowerCase();
            String replacement = coloredDigits.get(i);
            clearText = clearText.replaceFirst(" " + whatReplace, " " + replacement);
        }
        return Html.fromHtml(clearText);
    }

    public String searchHighlightedKeyword(String keyword) {
        String highlighted = "<font color='#ef2391'><b>$0</b></font>";
        return keyword.replaceAll("(?i)" + Pattern.quote(keyword), highlighted);
    }
}
