package com.example.cosmoinfo.data.di

import android.content.Context
import androidx.room.Room
import com.example.cosmoinfo.data.database.AppDatabase
import com.example.cosmoinfo.data.database.dao.BlogDao
import com.example.cosmoinfo.data.database.dao.PapersDao
import com.example.cosmoinfo.data.repository.ApiRepository
import com.example.cosmoinfo.data.repository.DaoRepository
import com.example.cosmoinfo.data.repository.FireStoreRepository
import com.example.cosmoinfo.data.repository.Repository
import com.example.cosmoinfo.data.services.constants.Constants.BASE_URL
import com.example.cosmoinfo.data.services.network.ApiService
import com.google.gson.FieldNamingPolicy
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object Di {

    private lateinit var contextProvider: () -> Context

    fun init(context: Context) {
        contextProvider = { context }
    }

    private val database: AppDatabase by lazy {
        Room.databaseBuilder(contextProvider(), AppDatabase::class.java, "articles_database")
            .build()
    }

    private val blogDao by lazy {
        database.blogsDao
    }

    private val daoRepository by lazy {
        DaoRepository(
            blogDao = blogDao
        )
    }

    private val okHttpClient by lazy {
        OkHttpClient.Builder().build()
    }

    private val gson by lazy {
        GsonBuilder().setFieldNamingPolicy(FieldNamingPolicy.IDENTITY).create()
    }

    private val apiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create(gson))
            .client(okHttpClient)
            .build()
            .create(ApiService::class.java)
    }

    private val apiRepository by lazy {
        ApiRepository(apiService)
    }

    private val fireStoreRepository by lazy {
        FireStoreRepository()
    }

    val repository: Repository by lazy {
        Repository(
            context = contextProvider(),
            fireStoreRepository = fireStoreRepository,
            apiRepository = apiRepository,
            daoRepository = daoRepository
        )
    }
}