package com.example.cosmoinfo.ui.activities.blogs

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cosmoinfo.data.model.blog.BlogTable
import com.example.cosmoinfo.data.model.paper.Paper
import com.example.cosmoinfo.data.repository.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BlogsViewModel(
    private val repository: Repository,
    private val categoryName: String
) :
    ViewModel() {

    private val _liveDataBlogsList = MutableLiveData<List<BlogTable>>()
    val liveDataBlogsList: LiveData<List<BlogTable>> =
        _liveDataBlogsList
    private var shuffleList = listOf<BlogTable>()

    init {
        subscribeSomeCategoryArticlesList()
    }

    fun shuffleList(){
        viewModelScope.launch(Dispatchers.IO) {
            shuffleList = shuffleList.shuffled()
            _liveDataBlogsList.postValue(shuffleList)
        }
    }

    private fun subscribeSomeCategoryArticlesList() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.sharedFlowBlogsList.collect {
                _liveDataBlogsList.postValue(it)
                shuffleList = it
            }
        }
    }
}