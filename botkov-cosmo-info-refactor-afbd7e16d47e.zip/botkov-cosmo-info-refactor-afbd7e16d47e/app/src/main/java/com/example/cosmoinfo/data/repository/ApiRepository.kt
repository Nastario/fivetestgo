package com.example.cosmoinfo.data.repository

import com.example.cosmoinfo.data.services.network.ApiService

class ApiRepository(private val apiService: ApiService) {

    suspend fun getBlogs(url: String) = apiService.getBlogs(url)
}