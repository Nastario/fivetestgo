package com.example.cosmoinfo.data.services.constants

import android.content.Context
import android.net.ConnectivityManager

object Constants {

    const val CATEGORY_NAME = "category_name"
    const val ID_KEY = "id_key"
    const val ARTICLE_ID = "article_id"
    const val TOAST_CLICK_BACK_TO_EXIT = "Please click BACK again to exit"
    const val BASE_URL = "https://base.url"

    fun checkInternetConnection(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val netInfo = cm.activeNetworkInfo
        return netInfo != null && netInfo.isConnectedOrConnecting
    }

}