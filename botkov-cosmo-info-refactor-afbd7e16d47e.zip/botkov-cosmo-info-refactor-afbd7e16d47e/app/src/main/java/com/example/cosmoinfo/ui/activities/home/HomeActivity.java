package com.example.cosmoinfo.ui.activities.home;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.cosmoinfo.R;
import com.example.cosmoinfo.data.di.Di;
import com.example.cosmoinfo.data.model.rank.Rank;
import com.example.cosmoinfo.data.services.base_activity.BaseActivity;
import com.example.cosmoinfo.data.services.onclick_service.RankOnClicked;
import com.example.cosmoinfo.data.services.onclick_service.PrivacyOnClicked;
import com.example.cosmoinfo.databinding.ActivityHomeBinding;
import com.example.cosmoinfo.ui.activities.home.adapter.RankAdapter;
import com.example.cosmoinfo.ui.activities.blogs.BlogsActivity;
import com.example.cosmoinfo.ui.activities.privacy.PrivacyActivity;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class HomeActivity extends BaseActivity implements RankOnClicked, PrivacyOnClicked {

    private static final String TOAST_CLICK_BACK_TO_EXIT = "Please click BACK again to exit";
    private static final String CATEGORY_NAME = "category_name";

    private ActivityHomeBinding binding;
    private List<Rank> ranks;
    private HomeViewModel homeViewModel;
    private Boolean doubleBackToExitPressedOnce = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        HomeViewModelFactory factory = new HomeViewModelFactory(Di.INSTANCE.getRepository());
        homeViewModel = new ViewModelProvider(this, (ViewModelProvider.Factory) factory).get(HomeViewModel.class);

        ranks = homeViewModel.getCategories();

        binding.readBlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), BlogsActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString(CATEGORY_NAME, "Blogs");
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
//        init();
    }

    @Override
    public void init() {
//        RankAdapter rankAdapter = new RankAdapter(this, this, this);
//        int resId = R.anim.layout_animation_fall_down;
//        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(this, resId);
//        binding.categoriesList.setLayoutAnimation(animation);
//        binding.categoriesList.setAdapter(rankAdapter);
//        binding.categoriesList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
//        binding.categoriesList.setMotionEventSplittingEnabled(false);
//        rankAdapter.setCategories(ranks);
//        binding.categoriesList.scheduleLayoutAnimation();
    }

    @Override
    public void onClickItemCategory(int id) {
        Intent intent = new Intent(this, BlogsActivity.class);
        Bundle bundle = new Bundle();
        bundle.putString(CATEGORY_NAME, ranks.get(id).getTitle());
        intent.putExtras(bundle);
        startActivity(intent);
    }


    @Override
    public void onClickPrivacyItem() {
        startActivity(new Intent(this, PrivacyActivity.class));
    }

    @Override
    public void showSnack(String massage) {
        Snackbar snackbar = Snackbar.make(binding.getRoot(), massage, Snackbar.LENGTH_LONG);
        snackbar.show();
    }

    @Override
    public void showToast(String massage) {
        Toast.makeText(this, massage, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void setClicks() {
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            finish();
            return;
        }
        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, TOAST_CLICK_BACK_TO_EXIT, Toast.LENGTH_SHORT).show();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                doubleBackToExitPressedOnce = false;
            }
        }, 2000);
    }
}