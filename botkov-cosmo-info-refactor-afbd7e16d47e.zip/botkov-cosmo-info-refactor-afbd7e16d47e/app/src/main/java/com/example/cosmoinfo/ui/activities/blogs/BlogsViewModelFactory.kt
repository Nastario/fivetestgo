package com.example.cosmoinfo.ui.activities.blogs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.cosmoinfo.data.repository.Repository

class BlogsViewModelFactory(
    private val repository: Repository,
    private val categoryName: String
) : ViewModelProvider.NewInstanceFactory() {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BlogsViewModel::class.java)) {
            return BlogsViewModel(repository, categoryName) as T
        }
        throw IllegalArgumentException("Unknown View Model class")
    }
}