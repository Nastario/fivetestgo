package com.example.cosmoinfo.data.repository

import android.content.Context
import android.util.Log
import com.example.cosmoinfo.data.services.UrlLoadingState
import com.example.cosmoinfo.data.services.constants.Constants.checkInternetConnection
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow

class FireStoreRepository() {

    private val db = Firebase.firestore
    private val job = SupervisorJob()
    private val scope = CoroutineScope(job + Dispatchers.IO)

    val sharedFlowLoadingUrlState = MutableSharedFlow<UrlLoadingState>()

    suspend fun checkURL(context: Context) {
        sharedFlowLoadingUrlState.emit(UrlLoadingState.LOADING)
        try {
            withTimeout(6000) {
                while (true) {
                    if (checkInternetConnection(context)) {
                        getUrlFromFirebaseAsync()
                        return@withTimeout
                    }
                    delay(500)
                }
            }
        } catch (e: Exception) {
            sharedFlowLoadingUrlState.emit(UrlLoadingState.error(e.toString()))
        }
    }

    private fun getUrlFromFirebaseAsync() {
        db.collection("cosmo_info_refactor")
            .get()
            .addOnSuccessListener { result ->
                try {
                    for (document in result) {
                        val url = document.data.getValue("url").toString()
                        Log.d("test", url)
                        scope.launch {
                            sharedFlowLoadingUrlState.emit(UrlLoadingState.success(url))
                        }
                    }
                } catch (e: Exception) {
                    Log.d("test", "error")
                    scope.launch { sharedFlowLoadingUrlState.emit(UrlLoadingState.error(e.toString())) }
                }
            }
            .addOnFailureListener { exception ->
                Log.d("test", "error")
                scope.launch { sharedFlowLoadingUrlState.emit(UrlLoadingState.error(exception.toString())) }
            }
    }
}