package com.example.cosmoinfo.data.services.onclick_service;

public interface RankOnClicked {
    void onClickItemCategory(int id);
}
