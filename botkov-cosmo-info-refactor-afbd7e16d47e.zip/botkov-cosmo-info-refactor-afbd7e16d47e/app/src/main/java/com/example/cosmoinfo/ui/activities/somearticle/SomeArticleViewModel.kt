package com.example.cosmoinfo.ui.activities.somearticle

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cosmoinfo.data.model.blog.BlogTable
import com.example.cosmoinfo.data.model.paper.Paper
import com.example.cosmoinfo.data.repository.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SomeArticleViewModel(private val repository: Repository, private val id: Int) : ViewModel() {

    private val _liveDataSomeArticle = MutableLiveData<BlogTable>()
    val liveDataSomeArticle: LiveData<BlogTable> = _liveDataSomeArticle

    init {
        subscribeSomeArticle()
    }

    fun emitSomeArticle() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.emitSomeArticle(id)
        }
    }

    private fun subscribeSomeArticle() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.sharedFlowSomeArticle.collect {
                _liveDataSomeArticle.postValue(it)
            }
        }
    }
}