package com.example.cosmoinfo.data.model.paper

import com.google.gson.annotations.SerializedName

data class FullPicture(
    @SerializedName("url")
    val fullPictureUrl: String
)