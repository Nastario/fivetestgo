package com.example.cosmoinfo.ui.activities.home.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cosmoinfo.R;
import com.example.cosmoinfo.data.model.rank.Rank;
import com.example.cosmoinfo.data.services.onclick_service.RankOnClicked;
import com.example.cosmoinfo.data.services.onclick_service.PrivacyOnClicked;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("NotifyDataSetChanged")
public class RankAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final ArrayList<Rank> ranks = new ArrayList<>();
    private final Context context;
    private final RankOnClicked rankOnClicked;
    private final PrivacyOnClicked privacyOnClicked;

    private final int VIEW_TYPE_CATEGORY = 0;
    private final int VIEW_TYPE_PRIVACY_POLICY = 1;


    public RankAdapter(Context context, RankOnClicked rankOnClicked, PrivacyOnClicked privacyOnClicked) {
        this.context = context;
        this.rankOnClicked = rankOnClicked;
        this.privacyOnClicked = privacyOnClicked;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_CATEGORY)
            return new RankViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category, parent, false));
        else
            return new PrivacyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_privacy_policy, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof RankViewHolder) {
            Rank rank = ranks.get(position);
            Glide.with(context).load(rank.getImage()).into(((RankViewHolder) holder).image);
            ((RankViewHolder) holder).title.setText(rank.getTitle());
            ((RankViewHolder) holder).subTitle.setText(rank.getSubtitle());
            ((RankViewHolder) holder).start.setOnClickListener(v -> rankOnClicked.onClickItemCategory(position));
        } else if (holder instanceof PrivacyViewHolder) {
            holder.itemView.setOnClickListener(view -> {
                privacyOnClicked.onClickPrivacyItem();
            });
        }
    }


    @Override
    public int getItemViewType(int position) {
        if (position >= ranks.size()){
            return VIEW_TYPE_PRIVACY_POLICY;
        }
        else{
            return VIEW_TYPE_CATEGORY;
        }
    }

    @Override
    public int getItemCount() {
        return ranks.size();
    }

    public void setCategories(List<Rank> ranks) {
        this.ranks.clear();
        this.ranks.addAll(ranks);
        notifyDataSetChanged();
    }
}
