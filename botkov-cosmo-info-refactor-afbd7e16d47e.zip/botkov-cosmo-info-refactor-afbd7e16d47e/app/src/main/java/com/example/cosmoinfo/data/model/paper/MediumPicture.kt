package com.example.cosmoinfo.data.model.paper

import com.google.gson.annotations.SerializedName

data class MediumPicture(
    @SerializedName("url")
    val mediumPictureUrl: String
)