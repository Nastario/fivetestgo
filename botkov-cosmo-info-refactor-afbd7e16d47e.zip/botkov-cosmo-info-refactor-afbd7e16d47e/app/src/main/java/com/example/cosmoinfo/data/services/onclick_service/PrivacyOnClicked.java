package com.example.cosmoinfo.data.services.onclick_service;

public interface PrivacyOnClicked {
    void onClickPrivacyItem();
}
