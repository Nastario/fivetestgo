package com.example.cosmoinfo.data.repository

import android.content.Context
import com.example.cosmoinfo.data.model.blog.Blog
import com.example.cosmoinfo.data.model.blog.BlogTable
import com.example.cosmoinfo.data.model.blog.BlogTable.Companion.blogsToDatabaseBlogs
import com.example.cosmoinfo.data.model.paper.Paper
import com.example.cosmoinfo.data.model.paper.PaperForDb
import com.example.cosmoinfo.data.model.paper.PaperForDb.Companion.convertFromDb
import com.example.cosmoinfo.data.model.rank.Rank
import com.example.cosmoinfo.data.services.LoadingState
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.map

class Repository(
    private val context: Context,
    private val fireStoreRepository: FireStoreRepository,
    private val apiRepository: ApiRepository,
    private val daoRepository: DaoRepository
) {
    private val categories = Rank.ranks

    var sharedFlowSomeCategoryArticlesList = MutableSharedFlow<List<BlogTable>>()
    val sharedFlowSomeArticle = MutableSharedFlow<BlogTable>()
    val sharedFlowBlogsLoadingState = MutableSharedFlow<LoadingState>()
    val sharedFlowInternetConnectionState =
        fireStoreRepository.sharedFlowLoadingUrlState.map { it }

    val sharedFlowBlogsList = daoRepository.getFlowBlogs().map { it }

    suspend fun emitSomeArticle(articleId: Int) {
        val someArticle = daoRepository.getSomeBlog(articleId)
        sharedFlowSomeArticle.emit(someArticle)
    }

    suspend fun getBlogs(url: String) {
        sharedFlowBlogsLoadingState.emit(LoadingState.LOADING)
        var blogs = listOf<Blog>()
        try {
            blogs = apiRepository.getBlogs(url)
        } catch (e: Exception) {
            sharedFlowBlogsLoadingState.emit(LoadingState.error(e.toString()))
        }
        if (blogs.isNotEmpty()) {
            daoRepository.deleteBlogs()
            daoRepository.addBlogs(blogsToDatabaseBlogs(blogs))
            sharedFlowBlogsLoadingState.emit(LoadingState.SUCCESS)
        }
    }

    fun getCategories(): List<Rank> {
        return categories
    }

    suspend fun checkUrl() {
        fireStoreRepository.checkURL(context)
    }


    fun emitArticlesSomeCategory(categoryName: String) {
        sharedFlowSomeCategoryArticlesList = sharedFlowBlogsList.map { it } as MutableSharedFlow
    }
}