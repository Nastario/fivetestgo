package com.example.cosmoinfo.ui.activities.blogs.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.cosmoinfo.R;
import com.example.cosmoinfo.data.model.blog.BlogTable;
import com.example.cosmoinfo.data.model.paper.Paper;
import com.example.cosmoinfo.data.services.onclick_service.PaperOnClicked;

import java.util.ArrayList;
import java.util.List;

@SuppressLint("NotifyDataSetChanged")
public class BlogsAdapter extends RecyclerView.Adapter<BlogsViewHolder> {

    private final ArrayList<BlogTable> blogs = new ArrayList<>();
    private final Context context;
    private final PaperOnClicked paperOnclicked;


    public BlogsAdapter(Context context, PaperOnClicked paperOnclicked) {
        this.context = context;
        this.paperOnclicked = paperOnclicked;
    }

    @NonNull
    @Override
    public BlogsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new BlogsViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_article, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull BlogsViewHolder holder, int position) {
        BlogTable blogTable = blogs.get(position);
        Glide.with(context).load(blogTable.getImg()).into(holder.image);
        holder.title.setText(blogTable.getTitle());
//        holder.subTitle.setText(blogTable.getExcerpt());
        holder.itemView.setOnClickListener(view -> {
            paperOnclicked.onClick(blogTable.getId());
        });
    }

    @Override
    public int getItemCount() {
        return blogs.size();
    }

    public void setArticles(List<BlogTable> blogs) {
        this.blogs.clear();
        this.blogs.addAll(blogs);
        notifyDataSetChanged();
    }
}
