package com.example.cosmoinfo.data.repository

import com.example.cosmoinfo.data.database.dao.BlogDao
import com.example.cosmoinfo.data.model.blog.BlogTable

class DaoRepository(private val blogDao: BlogDao) {

    fun addBlogs(blogs: List<BlogTable>) = blogDao.addBlogs(blogs)

    fun deleteBlogs() = blogDao.deleteBlogs()

    fun getBlogs() = blogDao.getBlogs()

    fun getFlowBlogs() = blogDao.getFlowBlogs()

    fun getSomeBlog(id: Int) = blogDao.getSomeBlog(id)
}