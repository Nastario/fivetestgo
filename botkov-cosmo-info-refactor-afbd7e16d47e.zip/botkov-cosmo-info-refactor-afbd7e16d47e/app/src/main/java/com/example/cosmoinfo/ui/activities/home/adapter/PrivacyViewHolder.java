package com.example.cosmoinfo.ui.activities.home.adapter;

import android.view.View;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class PrivacyViewHolder extends RecyclerView.ViewHolder {

    public PrivacyViewHolder(@NonNull View itemView) {
        super(itemView);
    }
}
