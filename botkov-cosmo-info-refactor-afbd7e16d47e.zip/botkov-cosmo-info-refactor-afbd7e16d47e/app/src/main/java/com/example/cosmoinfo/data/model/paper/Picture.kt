package com.example.cosmoinfo.data.model.paper

data class Picture(
    val fullPicture: FullPicture,
    val thumbnailPicture: ThumbnailPicture,
    val mediumPicture: MediumPicture

)

