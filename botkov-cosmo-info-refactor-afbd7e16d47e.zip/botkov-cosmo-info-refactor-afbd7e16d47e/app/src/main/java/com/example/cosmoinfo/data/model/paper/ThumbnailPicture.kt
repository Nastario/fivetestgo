package com.example.cosmoinfo.data.model.paper

import com.google.gson.annotations.SerializedName

data class ThumbnailPicture(
    @SerializedName("url")
    val thumbnailPictureUrl: String
)