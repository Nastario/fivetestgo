package com.example.cosmoinfo.data.model.paper

import com.google.gson.annotations.SerializedName

data class Paper(
    val id: Int,
    val title: String,
    val content: String,
    val excerpt: String,
    @SerializedName("thumbnail_images")
    val picture: Picture
)
