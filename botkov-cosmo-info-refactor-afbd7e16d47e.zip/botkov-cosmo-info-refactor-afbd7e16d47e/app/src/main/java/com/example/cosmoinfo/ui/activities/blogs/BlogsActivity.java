package com.example.cosmoinfo.ui.activities.blogs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.Toast;

import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.cosmoinfo.R;
import com.example.cosmoinfo.data.di.Di;
import com.example.cosmoinfo.data.services.base_activity.BaseActivity;
import com.example.cosmoinfo.data.services.onclick_service.PaperOnClicked;
import com.example.cosmoinfo.databinding.ActivityArticlesBinding;
import com.example.cosmoinfo.ui.activities.blogs.adapter.BlogsAdapter;
import com.example.cosmoinfo.ui.activities.somearticle.SomeArticleActivity;
import com.google.android.material.snackbar.Snackbar;

public class BlogsActivity extends BaseActivity implements SwipeRefreshLayout.OnRefreshListener, PaperOnClicked {

    private static final String CATEGORY_NAME = "category_name";
    private static final String ARTICLE_ID = "article_id";

    private ActivityArticlesBinding binding;
    private BlogsAdapter blogsAdapter;
    private BlogsViewModel blogsViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityArticlesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        String categoryName = getIntent().getExtras().getString(CATEGORY_NAME, "");

        BlogsViewModelFactory factory = new BlogsViewModelFactory(Di.INSTANCE.getRepository(), categoryName );
        blogsViewModel = new ViewModelProvider(this, (ViewModelProvider.Factory) factory).get(BlogsViewModel.class);

        init();
        subscribeSomeCategoryArticles();
        setClicks();
    }

    private void subscribeSomeCategoryArticles() {
        blogsViewModel.getLiveDataBlogsList().removeObservers(this);
        blogsViewModel.getLiveDataBlogsList().observe(this, someCategoryArticlesList -> {
            if (someCategoryArticlesList.isEmpty()){
                showError("Empty articles list");
            }
            blogsAdapter.setArticles(someCategoryArticlesList);
            binding.articlesList.scheduleLayoutAnimation();
            binding.swipeRefreshLayout.setRefreshing(false);
        });
    }

    @Override
    public void init() {
        blogsAdapter = new BlogsAdapter(this, this);
        binding.articleTitle.setText(getIntent().getExtras().getString(CATEGORY_NAME));
        binding.swipeRefreshLayout.setOnRefreshListener(this);
        binding.swipeRefreshLayout.setRefreshing(true);
        int resId = R.anim.layout_animation_fall_down;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(this, resId);
        binding.articlesList.setLayoutAnimation(animation);
        binding.articlesList.setAdapter(blogsAdapter);
        binding.articlesList.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        binding.articlesList.setMotionEventSplittingEnabled(false);

    }

    @Override
    public void setClicks() {
        binding.imageButtonBack.setOnClickListener(v -> finish());
    }

    @Override
    public void showToast(String massage) {
        Toast.makeText(this, massage, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void showSnack(String massage) {
        Snackbar snackbar = Snackbar.make(binding.getRoot(), massage, Snackbar.LENGTH_LONG);
        snackbar.setAction(R.string.retry, view -> {
            snackbar.dismiss();
            binding.swipeRefreshLayout.setRefreshing(true);
            new Handler().postDelayed(
                    this::subscribeSomeCategoryArticles
                    , 400);
        });
        snackbar.show();
    }

    @Override
    public void onRefresh() {
        blogsViewModel.shuffleList();
    }

    @Override
    public void onClick(int id) {
        Intent intent = new Intent(this, SomeArticleActivity.class);
        Bundle bundle = new Bundle();
        bundle.putInt(ARTICLE_ID, id);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    private void showError(String massage) {
        if (binding.swipeRefreshLayout.isRefreshing())
            binding.swipeRefreshLayout.setRefreshing(false);
        showSnack(massage);
    }
}