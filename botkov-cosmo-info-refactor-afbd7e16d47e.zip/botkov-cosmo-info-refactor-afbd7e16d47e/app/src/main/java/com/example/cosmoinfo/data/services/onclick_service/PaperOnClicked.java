package com.example.cosmoinfo.data.services.onclick_service;

public interface PaperOnClicked {
    void onClick(int id);
}
